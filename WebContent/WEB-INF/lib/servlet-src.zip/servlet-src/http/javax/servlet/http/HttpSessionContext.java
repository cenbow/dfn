// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HttpSessionContext.java

package javax.servlet.http;

import java.util.Enumeration;

// Referenced classes of package javax.servlet.http:
//			HttpSession

/**
 * @deprecated Interface HttpSessionContext is deprecated
 */

public interface HttpSessionContext
{

	/**
	 * @deprecated Method getSession is deprecated
	 */

	public abstract HttpSession getSession(String s);

	/**
	 * @deprecated Method getIds is deprecated
	 */

	public abstract Enumeration getIds();
}
