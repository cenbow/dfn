// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HttpServlet.java

package javax.servlet.http;

import java.io.IOException;
import java.util.ResourceBundle;
import javax.servlet.ServletOutputStream;

class NoBodyOutputStream extends ServletOutputStream
{

	private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
	private static ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
	private int contentLength;

	NoBodyOutputStream()
	{
		contentLength = 0;
	}

	int getContentLength()
	{
		return contentLength;
	}

	public void write(int b)
	{
		contentLength++;
	}

	public void write(byte buf[], int offset, int len)
		throws IOException
	{
		if (len >= 0)
		{
			contentLength += len;
		} else
		{
			String msg = lStrings.getString("err.io.negativelength");
			throw new IOException("negative length");
		}
	}

}
