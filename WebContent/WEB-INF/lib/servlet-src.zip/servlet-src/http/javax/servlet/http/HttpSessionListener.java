// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HttpSessionListener.java

package javax.servlet.http;

import java.util.EventListener;

// Referenced classes of package javax.servlet.http:
//			HttpSessionEvent

public interface HttpSessionListener
	extends EventListener
{

	public abstract void sessionCreated(HttpSessionEvent httpsessionevent);

	public abstract void sessionDestroyed(HttpSessionEvent httpsessionevent);
}
