// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   GenericServlet.java

package javax.servlet;

import java.io.IOException;
import java.io.Serializable;
import java.util.Enumeration;

// Referenced classes of package javax.servlet:
//			Servlet, ServletConfig, ServletException, ServletContext, 
//			ServletRequest, ServletResponse

public abstract class GenericServlet
	implements Servlet, ServletConfig, Serializable
{

	private transient ServletConfig config;

	public GenericServlet()
	{
	}

	public void destroy()
	{
	}

	public String getInitParameter(String name)
	{
		return getServletConfig().getInitParameter(name);
	}

	public Enumeration getInitParameterNames()
	{
		return getServletConfig().getInitParameterNames();
	}

	public ServletConfig getServletConfig()
	{
		return config;
	}

	public ServletContext getServletContext()
	{
		return getServletConfig().getServletContext();
	}

	public String getServletInfo()
	{
		return "";
	}

	public void init(ServletConfig config)
		throws ServletException
	{
		this.config = config;
		init();
	}

	public void init()
		throws ServletException
	{
	}

	public void log(String msg)
	{
		getServletContext().log((new StringBuilder()).append(getServletName()).append(": ").append(msg).toString());
	}

	public void log(String message, Throwable t)
	{
		getServletContext().log((new StringBuilder()).append(getServletName()).append(": ").append(message).toString(), t);
	}

	public abstract void service(ServletRequest servletrequest, ServletResponse servletresponse)
		throws ServletException, IOException;

	public String getServletName()
	{
		return config.getServletName();
	}
}
