// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServletException.java

package javax.servlet;


public class ServletException extends Exception
{

	public ServletException()
	{
	}

	public ServletException(String message)
	{
		super(message);
	}

	public ServletException(String message, Throwable rootCause)
	{
		super(message, rootCause);
	}

	public ServletException(Throwable rootCause)
	{
		super(rootCause);
	}

	public Throwable getRootCause()
	{
		return getCause();
	}
}
