// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ServletRequestEvent.java

package javax.servlet;

import java.util.EventObject;

// Referenced classes of package javax.servlet:
//			ServletContext, ServletRequest

public class ServletRequestEvent extends EventObject
{

	private ServletRequest request;

	public ServletRequestEvent(ServletContext sc, ServletRequest request)
	{
		super(sc);
		this.request = request;
	}

	public ServletRequest getServletRequest()
	{
		return request;
	}

	public ServletContext getServletContext()
	{
		return (ServletContext)super.getSource();
	}
}
